#include "MySkeletalMeshActor.h"

AMySkeletalMeshActor::AMySkeletalMeshActor()
{
    PrimaryActorTick.bCanEverTick = false;

    SkeletalMeshComponent = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("SkeletalMeshComponent"));
    RootComponent = SkeletalMeshComponent;
}
