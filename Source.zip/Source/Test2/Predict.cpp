#include "Predict.h"

#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Json.h"
#include "JsonUtilities.h"

#include "Engine/Engine.h" // Add this to use GEngine
#include "Async/Async.h"    // Add this to use AsyncTask

// Sets default values
APredict::APredict()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

// Called when the game starts or when spawned
void APredict::BeginPlay()
{
	Super::BeginPlay();
	// BeginPlay ȣ�� Ȯ���� ���� �α� �߰�
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Blue, TEXT("APredict BeginPlay called."));
	}
	UE_LOG(LogTemp, Log, TEXT("APredict BeginPlay called."));

	//SendHttpRequest();
}

void APredict::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

}

void APredict::SendHttpRequest()
{
	FHttpModule* Http = &FHttpModule::Get();

	// HTTP ��û ����
	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = Http->CreateRequest();
	Request->SetURL(TEXT("https://f106-219-240-96-223.ngrok-free.app/predict")); // ���� URL
	Request->SetVerb(TEXT("POST")); // HTTP POST ����
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json")); // JSON ���� ��� �߰�

	// JSON ������ �ۼ�
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());
	JsonObject->SetStringField("Date", "2024-11-28");     // ��¥
	JsonObject->SetNumberField("Day", 4);                // ���� (1: ������ ��)
	JsonObject->SetStringField("Time", "11:00");         // �ð�
	JsonObject->SetNumberField("Weather", 1);            // ���� (1: ���� ��)
	JsonObject->SetNumberField("Event", 0);              // �̺�Ʈ (0: ����)
	JsonObject->SetNumberField("Train_Arrival", 0);      // ���� ���� ���� (0: ����)

	// JSON ����ȭ
	FString JsonPayload;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonPayload);
	FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);

	// ��û ���� ����
	Request->SetContentAsString(JsonPayload);

	// �ݹ� �Լ� ����
	Request->OnProcessRequestComplete().BindLambda([this](FHttpRequestPtr RequestPtr, FHttpResponsePtr ResponsePtr, bool bWasSuccessful)
		{
			if (bWasSuccessful && ResponsePtr.IsValid())
			{
				FString LocalResponseContent = ResponsePtr->GetContentAsString();

				// JSON ���� ó��
				TSharedPtr<FJsonObject> JsonResponse;
				TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(LocalResponseContent);
				if (FJsonSerializer::Deserialize(Reader, JsonResponse))
				{
					// ȭ��� �α׿� ��� ���
					if (GEngine)
					{
						GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, TEXT("Successfully connected to server!"));
						GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::White, FString::Printf(TEXT("Response: %s"), *LocalResponseContent));
					}
					UE_LOG(LogTemp, Log, TEXT("Server Response: %s"), *LocalResponseContent);

					AsyncTask(ENamedThreads::GameThread, [this, LocalResponseContent]()
					{
						this->ResponseContent = LocalResponseContent;
						UE_LOG(LogTemp, Log, TEXT("ResponseContent member variable set to: %s"), *ResponseContent);

						OnHttpResponseReceived.Broadcast();
					});
				}
			}
			else
			{
				// ���� �� �α� ���
				if (GEngine)
				{
					GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("Failed to connect to server!"));
				}
				UE_LOG(LogTemp, Error, TEXT("Failed to connect to server!"));
			}
		});

	// ��û ����
	Request->ProcessRequest();
}

FString APredict::GetResponseContent() const
{
	return ResponseContent;
}
