// Copyright Epic Games, Inc. All Rights Reserved.

#include "Test2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Test2, "Test2" );
