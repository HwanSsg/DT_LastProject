#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "MySkeletalMeshActor.generated.h"

UCLASS()
class TEST2_API AMySkeletalMeshActor : public AActor
{
    GENERATED_BODY()

public:
    AMySkeletalMeshActor();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    USkeletalMeshComponent* SkeletalMeshComponent;
};
