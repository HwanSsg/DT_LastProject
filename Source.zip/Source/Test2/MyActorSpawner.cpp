#include "MyActorSpawner.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/Engine.h"
#include "Json.h"
#include "JsonUtilities.h"

// �⺻ ������
AMyActorSpawner::AMyActorSpawner()
{
    PrimaryActorTick.bCanEverTick = false;
    NumberOfPawns = 1;
}

void AMyActorSpawner::BeginPlay()
{
    Super::BeginPlay();

    // APredict ���� ���� ����
    if (PredictActor == nullptr)
    {
        TArray<AActor*> FoundActors;
        UGameplayStatics::GetAllActorsOfClass(GetWorld(), APredict::StaticClass(), FoundActors);
        if (FoundActors.Num() > 0)
        {
            PredictActor = Cast<APredict>(FoundActors[0]);
            UE_LOG(LogTemp, Log, TEXT("Found APredict actor: %s"), *PredictActor->GetName());
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("APredict actor not found in the level."));
        }
    }

    if (PredictActor)
    {
        PredictActor->OnHttpResponseReceived.AddDynamic(this, &AMyActorSpawner::OnHttpResponseReceivedHandler);
        UE_LOG(LogTemp, Log, TEXT("AMyActorSpawner bound to APredict's OnHttpResponseReceived delegate."));
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("AMyActorSpawner could not find APredict actor to bind."));
    }

    SpawnPawns();
}

void AMyActorSpawner::SpawnPawns()
{
    if (!PawnClassToSpawn)
    {
        UE_LOG(LogTemp, Warning, TEXT("PawnClassToSpawn is not set."));
        return;
    }

    for (AActor* Actor : SpawnedActors)
    {
        if (Actor)
        {
            Actor->Destroy();
        }
    }
    SpawnedActors.Empty();

    for (int32 i = 0; i < NumberOfPawns; ++i)
    {
        float positionY = 0.0f;
        float positionX = 0.0f;
        int32 count = 0;

        if (i < 22)
        {
            count = i / 2;
            positionY = (i % 2 == 0) ? 70.0f : 100.0f;
            positionX = -210.0f - count * 25.0f;
        }
        else
        {
            count = (i - 22) / 2;
            positionX = (i % 2 == 0) ? -500.0f : -480.0f;
            positionY = 120.0f + count * 25.0f;
            PawnRotation = FRotator(0.0f, -90.0f, 0.0f);
        }

        FVector LocationOffset = FVector(positionX, positionY, 6.0f);
        FVector SpawnLocation = GetActorLocation() + LocationOffset;
        FRotator SpawnRot = PawnRotation;

        FActorSpawnParameters SpawnParams;
        SpawnParams.Owner = this;
        SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

        APawn* NewPawn = GetWorld()->SpawnActor<APawn>(PawnClassToSpawn, SpawnLocation, SpawnRot, SpawnParams);

        if (NewPawn)
        {
            
            if (USkeletalMeshComponent* PawnMeshComp = NewPawn->FindComponentByClass<USkeletalMeshComponent>())
            {
                PawnMeshComp->SetWorldScale3D(PawnScale);
            }

            SpawnedActors.Add(NewPawn);
        }
    }
}

void AMyActorSpawner::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    Super::EndPlay(EndPlayReason);

    if (PredictActor)
    {
        PredictActor->OnHttpResponseReceived.RemoveDynamic(this, &AMyActorSpawner::OnHttpResponseReceivedHandler);
        UE_LOG(LogTemp, Log, TEXT("AMyActorSpawner unbound from APredict's OnHttpResponseReceived delegate."));
    }

    for (AActor* Actor : SpawnedActors)
    {
        if (Actor)
        {
            Actor->Destroy();
        }
    }
    SpawnedActors.Empty();
}

void AMyActorSpawner::OnHttpResponseReceivedHandler()
{
    if (PredictActor)
    {
        FString Response = PredictActor->GetResponseContent();
        UE_LOG(LogTemp, Log, TEXT("AMyActorSpawner received response: %s"), *Response);

        TSharedPtr<FJsonObject> JsonObject;
        TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Response);

        if (FJsonSerializer::Deserialize(Reader, JsonObject) && JsonObject.IsValid())
        {
            if (JsonObject->HasTypedField<EJson::Number>("prediction"))
            {
                int32 PredictionValue = JsonObject->GetNumberField("prediction");
                UE_LOG(LogTemp, Log, TEXT("Parsed Prediction Value: %d"), PredictionValue);

                NumberOfPawns = PredictionValue;
                SpawnPawns();
            }
            else
            {
                UE_LOG(LogTemp, Warning, TEXT("\"prediction\" field not found in JSON. Using default NumberOfPawns=1."));
                NumberOfPawns = 1;
                SpawnPawns();
            }
        }
        else
        {
            UE_LOG(LogTemp, Warning, TEXT("Failed to parse JSON response. Using default NumberOfPawns=1."));
            NumberOfPawns = 1;
            SpawnPawns();
        }
    }
    else
    {
        UE_LOG(LogTemp, Error, TEXT("AMyActorSpawner has no reference to APredict actor."));
    }
}
