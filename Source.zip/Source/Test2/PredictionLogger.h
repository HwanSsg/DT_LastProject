#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PredictionLogger.generated.h"

UCLASS()
class TEST2_API APredictionLogger : public AActor
{
    GENERATED_BODY()

public:
    virtual void BeginPlay() override;
};