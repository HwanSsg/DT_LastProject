#include "MyPlayerController.h"
#include "Blueprint/UserWidget.h"
#include "Engine/World.h"

void AMyPlayerController::BeginPlay()
{
    Super::BeginPlay();

    if (MyUserWidgetClass)
    {
        MyUserWidgetInstance = CreateWidget<UUserWidget>(this, MyUserWidgetClass);
        if (MyUserWidgetInstance)
        {
            MyUserWidgetInstance->AddToViewport();
        }
    }
}