#include "MyUserWidget.h"
#include "Components/EditableTextBox.h"
#include "Components/ComboBoxString.h"
#include "Components/CheckBox.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Dom/JsonObject.h"
#include "Serialization/JsonWriter.h"
#include "Serialization/JsonSerializer.h"
#include "Kismet/GameplayStatics.h"
#include "MyGameInstance.h"
#include "Predict.h"
#include "MyActorSpawner.h"
#include "PredictionResultWidget.h" 
#include "Blueprint/UserWidget.h"

void UMyUserWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (SendButton)
	{
		SendButton->OnClicked.AddDynamic(this, &UMyUserWidget::SendDataToServer);
	}

	// DayValues�� WeatherValues �� �ʱ�ȭ
	DayValues = {
		{ "Monday", 1 },
		{ "Tuesday", 2 },
		{ "Wednesday", 3 },
		{ "Thursday", 4 },
		{ "Friday", 5 },
	};

	WeatherValues = {
		{ "Sunny", 1 },
		{ "Cloudy", 2 },
		{ "Rainy", 3 },
		{ "Snowy", 4 }
	};
}

void UMyUserWidget::SendDataToServer()
{
	FHttpModule* Http = &FHttpModule::Get();

	// HTTP ��û ����
	TSharedRef<IHttpRequest, ESPMode::ThreadSafe> Request = Http->CreateRequest();
	Request->SetURL(TEXT("https://afaa-218-155-110-127.ngrok-free.app/predict"));
	Request->SetVerb(TEXT("POST"));
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json"));

	// JSON ������ �ۼ�
	TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

	// ��¥ �Է°� ��������
	FString DateString = DateTextBox->GetText().ToString();
	JsonObject->SetStringField("Date", DateString);

	// �ð� �Է°� ��������
	FString TimeString = TimeTextBox->GetText().ToString();
	JsonObject->SetStringField("Time", TimeString);

	// ���� ���ð� ��������
	FString DayKey = DayComboBox->GetSelectedOption();
	if (!DayValues.Contains(DayKey))
	{
		ResultText->SetText(FText::FromString("Invalid day selection."));
		return;
	}
	JsonObject->SetNumberField("Day", DayValues[DayKey]);

	// ���� ���ð� ��������
	FString WeatherKey = WeatherComboBox->GetSelectedOption();
	if (!WeatherValues.Contains(WeatherKey))
	{
		ResultText->SetText(FText::FromString("Invalid weather selection."));
		return;
	}
	JsonObject->SetNumberField("Weather", WeatherValues[WeatherKey]);

	// üũ�ڽ� �� ��������
	JsonObject->SetNumberField("Event", EventCheckBox->IsChecked() ? 1 : 0);
	JsonObject->SetNumberField("Train_Arrival", TrainCheckBox->IsChecked() ? 1 : 0);

	// JSON ����ȭ
	FString JsonPayload;
	TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&JsonPayload);
	FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);

	// ��û ���� ����
	Request->SetContentAsString(JsonPayload);

	// ���� ó�� �Լ� ���ε�
	Request->OnProcessRequestComplete().BindUObject(this, &UMyUserWidget::OnResponseReceived);

	// ��û ����
	Request->ProcessRequest();
}

void UMyUserWidget::OnResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	if (bWasSuccessful && Response.IsValid())
	{
		FString ResponseContent = Response->GetContentAsString();

		// ���� ���� �α� ���
		UE_LOG(LogTemp, Log, TEXT("Server Response: %s"), *ResponseContent);

		// JSON ���� ó��
		TSharedPtr<FJsonObject> JsonResponse;
		TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(ResponseContent);

		if (FJsonSerializer::Deserialize(Reader, JsonResponse))
		{
			if (JsonResponse->HasTypedField<EJson::Number>("prediction"))
			{
				int32 Prediction = JsonResponse->GetNumberField("prediction");


				TArray<AActor*> FoundActors;
				UGameplayStatics::GetAllActorsOfClass(GetWorld(), APredict::StaticClass(), FoundActors);

				TArray<AActor*> FoundActorSpawners;
				UGameplayStatics::GetAllActorsOfClass(GetWorld(), AMyActorSpawner::StaticClass(), FoundActorSpawners);
				if (FoundActorSpawners.Num() > 0)
				{
					AMyActorSpawner* myActorSpawner = Cast<AMyActorSpawner>(FoundActorSpawners[0]);
					myActorSpawner->NumberOfPawns = Prediction;
					myActorSpawner->SpawnPawns();
					
				}

				SetVisibility(ESlateVisibility::Collapsed);

				if (PredictionResultWidgetClass)
				{
					UUserWidget* PredictionResultWidget = CreateWidget<UUserWidget>(GetWorld(), PredictionResultWidgetClass);
					if (PredictionResultWidget)
					{
						// ���� ���� ����
						UPredictionResultWidget* PredictionResult = Cast<UPredictionResultWidget>(PredictionResultWidget);
						if (PredictionResult)
						{
							PredictionResult->SetPredictionText(FString::Printf(TEXT("Predicted Value: %d"), Prediction));
						}

						PredictionResultWidget->AddToViewport();
					}
					else
					{
						UE_LOG(LogTemp, Warning, TEXT("Failed to create PredictionResultWidget."));
					}
				}
				else
				{
					UE_LOG(LogTemp, Warning, TEXT("PredictionResultWidgetClass is not set."));
				}


				// �������� ȭ�鿡 ǥ��
				/*if (ResultText)
				{
					ResultText->SetText(FText::FromString(predict->ResponseContent));

				}*/
				

				// �ٸ� ������ �̵�
				//UGameplayStatics::OpenLevel(this, FName("BusStop"));
			}
			else
			{
				UE_LOG(LogTemp, Error, TEXT("Unexpected response from server."));
				if (ResultText)
				{
					ResultText->SetText(FText::FromString("Unexpected response from server."));
				}
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to parse JSON response."));
			if (ResultText)
			{
				ResultText->SetText(FText::FromString("Failed to parse JSON response."));
			}
		}
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to connect to server."));
		if (ResultText)
		{
			ResultText->SetText(FText::FromString("Failed to connect to server."));
		}
	}
}

