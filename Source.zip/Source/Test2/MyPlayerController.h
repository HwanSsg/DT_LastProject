#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "MyUserWidget.h"
#include "MyPlayerController.generated.h"

UCLASS()
class TEST2_API AMyPlayerController : public APlayerController
{
    GENERATED_BODY()

protected:
    virtual void BeginPlay() override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<class UUserWidget> MyUserWidgetClass;

    UPROPERTY()
    UUserWidget* MyUserWidgetInstance;
};
