#include "PredictionResultWidget.h"
#include "Components/TextBlock.h"

void UPredictionResultWidget::SetPredictionText(const FString& Prediction)
{
    if (PredictionTextBlock)
    {
        PredictionTextBlock->SetText(FText::FromString(Prediction));
    }
}
